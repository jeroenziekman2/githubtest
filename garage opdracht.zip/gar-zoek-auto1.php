<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="stylesheet.css">

</head>
<body>
<h1>garage zoekt op kenteken</h1>
<p>dit formulier zoekt een auto op uit de tabel auto van database garage</p>
<form action="gar-zoek-auto2.php" method="post">
    welk kenteken zoekt u.
    <input type="text" name="autokentekenvak"> <br>
    <input type="submit">
</form>
</body>
</html>
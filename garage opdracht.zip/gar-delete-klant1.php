<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="stylesheet.css">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>garage de;ete klant1</h1>
<p>dit formulier zoekr een klant op uit de tabel klanten van database garage m hem te kunnen verwijderen</p>
<form action="gar-delete-klant2.php" method="post">
    welke klantid wilt u verwijderen?
    <input type="text" name="klantidvak"><br>
    <input type="submit">
</form>
</body>
</html>
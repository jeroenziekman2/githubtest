<!doctype html>
<html>
<head>
    <title>gar-create-klant1.php</title>
    <link rel="stylesheet" href="stylesheet.css">
</head>
<body>
<h1>garage create klant 1</h1>
<p>
    Dit formulier wordt gebruikt om klantengegevens in te voeren
</p>
<form action="gar-create-auto2.php" method="post">
    autokenteken:      <input type="text" name="autokentekenvak">     <br />
    automerk:     <input type="text" name="automerkvak">    <br />
    autotype:  <input type="text" name="autotypevak"> <br />
    autokmafstand:    <input type="text" name="autokmafstandvak">   <br />
    klantid:    <input type="text" name="klantidvak">   <br />
    <input type="submit">
</form>
</body>
</html>